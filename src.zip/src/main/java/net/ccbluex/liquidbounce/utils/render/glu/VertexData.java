package net.ccbluex.liquidbounce.utils.render.glu;

public class VertexData {
    public double[] data;

    public VertexData(double[] data) {
        this.data = data;
    }
}

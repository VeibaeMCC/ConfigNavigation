/*
 * FDPClient Hacked Client
 * A free open source mixin-based injection hacked client for Minecraft using Minecraft Forge by LiquidBounce.
 * https://github.com/UnlegitMC/FDPClient/
 */
package net.ccbluex.liquidbounce.utils;

import net.minecraft.client.Minecraft;

public class MinecraftInstance {
    protected static final Minecraft mc = Minecraft.getMinecraft();
}
